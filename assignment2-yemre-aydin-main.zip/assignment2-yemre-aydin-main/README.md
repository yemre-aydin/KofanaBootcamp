# Simple Calculator
A Simple calculator developed with JavaScript
